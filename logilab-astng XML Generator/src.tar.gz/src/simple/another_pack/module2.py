import simple.pack.module1
def another_func1():
    simple.pack.module1.another_func()
