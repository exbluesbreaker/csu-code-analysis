def another_func():
    print "Another func"
