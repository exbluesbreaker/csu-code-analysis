# -*- coding: utf-8 -*-

factorial = lambda x: factorial(x - 1) * x if x > 1 else 1

